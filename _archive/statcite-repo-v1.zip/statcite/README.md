# StatCite

**Economic statistics your AI can actually cite.**

StatCite is a free remote MCP server + REST API serving official economic statistics — World Bank, IMF WEO, ECB reference rates, optional FRED — where **every number ships with its full citation**: source, dataset, series ID, canonical URL, license, retrieval date, and a ready-to-paste citation sentence. Plus **`verify_stat`**: check any claimed economic figure against the official series and get a verdict (`match / close / mismatch / cannot_verify`) with diagnostics for the classic errors (wrong year, percent-vs-decimal, millions-vs-billions).

- **Website & docs:** https://statcite.com · [docs](https://statcite.com/docs.html) · [OpenAPI](https://statcite.com/openapi.json) · [llms.txt](https://statcite.com/llms.txt)
- **MCP endpoint:** `https://statcite.com/mcp` (Streamable HTTP, stateless, no auth)
- **REST:** `https://statcite.com/v1/...`

## Quick connect

| Client | How |
|---|---|
| Claude (web/desktop) | Settings → Connectors → Add custom connector → `https://statcite.com/mcp` |
| Claude Code | `claude mcp add --transport http statcite https://statcite.com/mcp` |
| ChatGPT | Developer mode → add MCP server, No Authentication (also implements the deep-research `search`/`fetch` pair) |
| Cursor | `{"mcpServers":{"statcite":{"url":"https://statcite.com/mcp"}}}` |
| VS Code | `{"servers":{"statcite":{"type":"http","url":"https://statcite.com/mcp"}}}` |
| stdio-only | `npx -y mcp-remote@latest https://statcite.com/mcp` |

## Try it in 5 seconds

```bash
curl "https://statcite.com/v1/verify?indicator=inflation_cpi&country=USA&period=2023&value=4.1"
curl "https://statcite.com/v1/indicator/govt_debt_gdp?country=JPN&latest_only=true"
curl "https://statcite.com/v1/fx?amount=100&from=USD&to=BBD"
```

## Tools

`get_indicator` · `verify_stat` · `get_series` · `search_indicators` · `country_snapshot` · `inflation_adjust` · `fx_convert` · `list_sources` · `search` · `fetch` — 42 curated indicators, 200+ economies, ~120 currencies. All read-only. Details: [docs](https://statcite.com/docs.html).

## Repo layout

```
server/        Cloudflare Worker: MCP endpoint + REST API + tests (zero runtime deps)
site/          statcite.com static site (landing, docs, llms.txt, OpenAPI, legal)
apify/         Metered twin: Apify actor (pay-per-event) bundling the same core
skill/         Claude skill teaching agents the verify-then-cite workflow
distribution/  Registry manifests, submission steps, launch copy
docs/          Research report, strategy, launch plan, monetization roadmap
HANDOFF.md     Deployment runbook (start here to take it live)
```

## Develop

```bash
cd server
npm install
npm test          # 37 tests, fixture-backed, no network
npm run smoke     # live end-to-end against real upstream APIs
npm run dev       # wrangler dev (local Workers runtime + static site)
npm run deploy    # wrangler deploy
```

## Data & licensing

StatCite relays official statistics with attribution and adds no numbers of its own. World Bank (CC BY 4.0), IMF (attribution), ECB (attribution, informational rates), Eurostat via DBnomics (CC BY 4.0), optional FRED (operator key; mandated disclaimer included in citations). IMF WEO projections are labeled as projections. Server code: MIT.

Built and curated by a professional economist. Contact: hello@statcite.com
